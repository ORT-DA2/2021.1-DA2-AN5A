﻿using System.Linq;
using Entities;

namespace DataAccess.Contracts
{
    public interface IUsuarioDataAccess
    {
        void Add(Usuario entity);

        void Remove(Usuario entity);

        void Update(Usuario entity);

        IQueryable<Usuario> GetAll();

        Usuario Get(int id);

        void Save();
    }
}
