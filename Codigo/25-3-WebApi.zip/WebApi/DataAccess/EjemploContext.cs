using Entities;
using Microsoft.EntityFrameworkCore;

namespace DataAccess
{
    public class EjemploContext : DbContext
    {
        public DbSet<Usuario> Users {get; set;}

        public EjemploContext(DbContextOptions options) : base(options)
        {
            
        }

    }
}