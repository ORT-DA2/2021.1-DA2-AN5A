﻿using System;
using System.Linq;
using DataAccess.Contracts;
using Entities;
using Microsoft.EntityFrameworkCore;

namespace DataAccess
{
    public class UsuarioDataAccess : IUsuarioDataAccess
    {
        public UsuarioDataAccess(EjemploContext context) 
        {
            Context = context;
        }

        protected DbContext Context {get; set;}

        public void Add(Usuario entity) 
        {
            Context.Set<Usuario>().Add(entity);
        }

        public void Remove(Usuario entity) 
        {
            Context.Set<Usuario>().Remove(entity);
        }

        public void Update(Usuario entity) 
        {
            Context.Entry(entity).State = EntityState.Modified;
        }

        public void Save() 
        {
            Context.SaveChanges();
        }

        public IQueryable<Usuario> GetAll()
        {
            return Context.Set<Usuario>();
        }

        public Usuario Get(int id)
        {
            return Context.Set<Usuario>().FirstOrDefault(x => x.Id == id);
        }
    }
}
