﻿using System;
using System.Linq;
using DataAccess;
using DataAccess.Contracts;
using Entities;

namespace BusinessLogic
{
    public class UsuarioBusinessLogic
    {
        private IUsuarioDataAccess repository;

        public UsuarioBusinessLogic(IUsuarioDataAccess dataAccess) {
            this.repository = dataAccess;
        }

        public Usuario Create(Usuario user) 
        {
            repository.Add(user);
            repository.Save();
            return user;
        }

        public Usuario Get(int id) {
            return repository.Get(id);
        }

        public IQueryable<Usuario> GetAll() 
        {
            return repository.GetAll();
        }

        public void Remove(int id)
        {
            Usuario user = repository.Get(id);
            repository.Remove(user);
            repository.Save();
        }

        public Usuario Update(int id, Usuario entity)
        {
            Usuario user = repository.Get(id);

            return user;
        }
    }
}
