﻿using BusinessLogic;
using Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UsuariosController : ControllerBase
    {
        private UsuarioBusinessLogic servicio;

        public UsuariosController(UsuarioBusinessLogic usuario)
        {
            servicio = usuario;
        }

        [HttpGet("{id}")]
        public IActionResult Get([FromRoute]int id)
        {
            var usuario = servicio.Get(id);
            if (usuario == null) 
            {
                return NotFound();
            }
            return Ok(usuario);
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(servicio.GetAll());
        }

        [HttpPost]
        public IActionResult Post([FromBody] Usuario usuario)
        {
            return Ok(servicio.Create(usuario));
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteUsuario(int id)
        {
            servicio.Remove(id);
            return NoContent();
        }
    }
}
