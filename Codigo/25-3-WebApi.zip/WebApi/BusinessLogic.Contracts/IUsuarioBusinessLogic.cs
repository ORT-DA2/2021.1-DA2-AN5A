﻿using System;
using System.Linq;
using Entities;

namespace BusinessLogic.Contracts
{
    public interface IUsuarioBusinessLogic
    {
        Usuario Create(Usuario user);

        Usuario Get(int id);

        IQueryable<Usuario> GetAll();

        void Remove(int id);

        Usuario Update(int id, Usuario entity);
    }
}
