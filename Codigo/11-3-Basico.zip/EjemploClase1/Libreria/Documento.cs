using System;
using System.Collections.Generic;

namespace Libreria
{
    public class Documento
    {
        public int Id { get; set; }
        
        public List<PersonaDocumento> PersonaDocumento { get; set; }
    }
}
