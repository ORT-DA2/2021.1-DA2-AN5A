using System;

namespace Libreria
{
    public class PersonaDocumento
    {
        public int PersonaId { get; set; }
        public Persona Persona { get; set; }
        public int DocumentoId { get; set; }
        public Documento Documento { get; set; }
    }
}
