using Microsoft.EntityFrameworkCore;

namespace Libreria
{
    public class LibreriaContext : DbContext
    {   
        public DbSet<PersonaDocumento> PersonasDocumentos { get; set; }
        public DbSet<Persona> Personas { get; set; }
        public DbSet<Documento> Documentos { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=myServerAddress;Database=myDataBase;Trusted_Connection=True;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder) 
        {
            modelBuilder.Entity<Persona>(persona => {
                persona.HasKey(x => x.Id);

                persona.HasIndex(x => x.Nombre);
                persona.HasIndex(x => x.Apellido);
                persona.HasIndex(x => new { x.Apellido, x.Nombre });

                persona.HasMany(x => x.PersonaDocumento)
                    .WithOne(personaDocumento => personaDocumento.Persona)
                    .HasForeignKey(personaDocumento => personaDocumento.PersonaId);
            });

            modelBuilder.Entity<Documento>(documento => {
                documento.HasKey(x => x.Id);

                documento.HasMany(x => x.PersonaDocumento)
                    .WithOne(personaDocumento => personaDocumento.Documento)
                    .HasForeignKey(personaDocumento => personaDocumento.DocumentoId);
            });

            modelBuilder.Entity<PersonaDocumento>(personaDocumento => {
                personaDocumento.HasKey(x => new { x.DocumentoId, x.PersonaId });
            });
        }

        
    }
}