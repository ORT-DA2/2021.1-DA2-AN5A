﻿using System;
using Libreria;

namespace Main
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = new Persona();
            foreach (var pd in a.PersonaDocumento)
            {
                if (pd.Documento.Id == 3) 
                {

                }
            }
            Console.WriteLine("Hello World!");
        }
    }
}
