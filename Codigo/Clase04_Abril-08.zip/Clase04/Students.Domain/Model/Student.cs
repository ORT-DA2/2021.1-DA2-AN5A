﻿using System;

namespace Students.Domain.Model
{
    public class Student
    {        
        public int Id { get; set; }

        public string Name { get; set; }

        public int YearOfBirth { get; set; }
    }
}
