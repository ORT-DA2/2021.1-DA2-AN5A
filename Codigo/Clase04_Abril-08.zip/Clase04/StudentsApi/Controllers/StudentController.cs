﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Students.BusinessLogic;
using Students.Domain.Model;
using Students.BusinessLogic.Validators;
using System;

namespace Students.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        IStudentService _studentBusinessLogic;
        IStudentValidator _studentValidator;


        public StudentController(IStudentService studentBusinessLogic, IStudentValidator studentValidator)
        {
            _studentBusinessLogic = studentBusinessLogic;
            _studentValidator = studentValidator;
        }
        

        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        /**********************************************************************************************************************
         * Método Post "Original" que vimos en clase el 8 de abril. Requiere modificaciones para poder ser realmente testeable
         * ********************************************************************************************************************/
        //[HttpPost]
        //public IActionResult Post([FromBody] Student student)
        //{
        //    StudentValidator validator = new StudentValidator();
        //    CustomValidationResult result = validator.Validate(student);
        //    if (result.IsValid)
        //    {
        //        _studentBusinessLogic.AddStudent(student);
        //        return CreatedAtRoute("Get", new { id = student.Id }, student);
        //    }

        //    return BadRequest(result);
        //}

        /*********************************************************************************************************************
         * Método Post modificado y testeable :)
         * (Ya no crea su instancia de StudentValidator, sino que utiliza la dependencia inyectada mediante su constructor
         * *******************************************************************************************************************/
        [HttpPost]
        public IActionResult Post([FromBody] Student student)
        {
            try
            {
                CustomValidationResult result = _studentValidator.Validate(student);
                if (result.IsValid)
                {
                    _studentBusinessLogic.AddStudent(student);
                    return CreatedAtRoute("Get", new { id = student.Id }, student);
                }
                return BadRequest(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ha ocurrido un problema al intentar registrar al estudiante");
            }
           
        }
    }
}
