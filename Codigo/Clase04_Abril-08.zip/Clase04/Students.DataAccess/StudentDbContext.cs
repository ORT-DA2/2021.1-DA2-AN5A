﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Students.Domain.Model;

namespace Students.DataAccess
{
    public class StudentDbContext : DbContext
    {       
        public DbSet<Student> Students { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            if (!options.IsConfigured)
            {
                options.UseSqlServer("server=(Local)\\SQLEXPRESS; database=StudentsDB; Integrated Security=true");
            }
        }

    }
}
