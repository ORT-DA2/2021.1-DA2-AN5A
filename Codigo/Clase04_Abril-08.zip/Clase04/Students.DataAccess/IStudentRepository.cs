﻿using Students.Domain.Model;

namespace Students.DataAccess
{
    public interface IStudentRepository
    {
        void AddStudent(Student student);
    }
}
