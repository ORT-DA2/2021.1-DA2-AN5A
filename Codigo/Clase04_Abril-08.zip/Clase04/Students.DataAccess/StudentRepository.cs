﻿using Students.Domain.Model;
using System;

namespace Students.DataAccess
{
    public class StudentRepository : IStudentRepository
    {
        StudentDbContext _dbContext;
                
        private StudentDbContext Context
        {
            get
            {
                if (_dbContext == null)
                {
                    _dbContext = new StudentDbContext();
                }
                return _dbContext;
            }
        }

        public void AddStudent(Student student)
        {
            if (student == null)
            {             
                throw new Exception("Datos de estudiante inválidos");
            }

            Context.Add(student);
            Context.SaveChanges();
        }
    }
}
