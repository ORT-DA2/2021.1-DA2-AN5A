﻿using Students.Domain.Model;

namespace Students.BusinessLogic
{
    public interface IStudentService 
    {
        void AddStudent(Student student);
    }
}
