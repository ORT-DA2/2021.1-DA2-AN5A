﻿using Students.Domain.Model;

namespace Students.BusinessLogic.Validators
{
    public interface IStudentValidator
    {
        public CustomValidationResult Validate(Student student);
    }
}
