﻿
using Students.Domain.Model;
using System;
using System.Collections.Generic;

namespace Students.BusinessLogic.Validators
{
    public class StudentValidator : IStudentValidator
    {

        /// <summary>
        /// Ejecuta la validación de un objeto en base a reglas de negocio definidas.
        /// </summary>
        /// <param name="student"></param>
        /// <returns></returns>
        public CustomValidationResult Validate(Student student)
        {
            //Asumimos una postura optimista, y comenzamos por definir un estado de "Válido" para el objeto. (Podría ser al contrario)
            bool isValid = true;
            List<string> errorsFound = new List<string>();

            //1) Un objeto nulo produce una excepción
            if (student == null)
            {
                //En este caso, directamente retornamos, no podemos realizar más validaciones si el objeto es nulo.
                throw new Exception("Objeto nulo");
            }

            //2) El nombre es un campo requerido
            if (string.IsNullOrEmpty(student.Name))
            {
                isValid = false;
                errorsFound.Add("El nombre es un campo requerido");
            }

            //3) El año de nacimiento debe ser válido
            if (student.YearOfBirth <= 0)
            {
                isValid = false;
                errorsFound.Add("El año de nacimiento es inválido");
            }
            else
            {
                //4) Debe ser mayor de edad o cumplir la mayoría de edad este año (18)
                if (DateTime.Today.Year - student.YearOfBirth < 18)
                {
                    isValid = false;
                    errorsFound.Add("Debe ser mayor de edad");
                }
            }
            CustomValidationResult result = new CustomValidationResult(isValid, errorsFound);
            return result;
        }
    }
}
