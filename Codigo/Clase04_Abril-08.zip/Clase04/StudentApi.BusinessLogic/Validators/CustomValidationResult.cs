﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Students.BusinessLogic.Validators
{
    public class CustomValidationResult
    {
        private List<string> _errorMessages;
               
        public CustomValidationResult(bool isValid, List<string> errorMessages)
        {            
            IsValid = isValid;

            if (isValid)
            {
                //No hay errores, guardo una lista vacía a título informativo.
                _errorMessages = new List<string>();
            }
            else
            {
                //TODO: Agregar tests para probar la siguiente situación, quiero comprobar que la excepción se lance cuando se cumple la condición.
                if (errorMessages == null || errorMessages.Count == 0)
                {
                    throw new ApplicationException("Si un objecto es inválido, se debe especifacar al menos un mensaje de error");
                }

                //Si determiné que el objecto no es válido, entonces guardo los mensajes para los errores detectactos.
                _errorMessages = errorMessages;
            }
        }

        public bool IsValid
        {
            get; private set;
        }

        public List<string> ErrorMessages
        {
            get
            {
                return _errorMessages;
            }
        }

    }
}
