﻿using Students.DataAccess;
using Students.Domain.Model;
using Students.BusinessLogic.Validators;
using System;

namespace Students.BusinessLogic
{
    public class StudentService : IStudentService
    {
        IStudentRepository _studentRepository;
        IStudentValidator _studentValidator;

               
        public StudentService(IStudentRepository studentRepository, IStudentValidator validator)
        {
            _studentRepository = studentRepository;
            _studentValidator = validator;            
        }

        public void AddStudent(Student student)
        {
            CustomValidationResult result = _studentValidator.Validate(student);
            if (result.IsValid)
            {
                _studentRepository.AddStudent(student);
            }
            else
            {
                throw new Exception("Datos de estudiante inválidos");
            }
        }
    }
}
