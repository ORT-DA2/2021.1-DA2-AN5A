﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Students.Api.Controllers;
using Students.Domain.Model;
using Students.BusinessLogic;
using Students.BusinessLogic.Validators;
using Moq;
using System.Collections.Generic;
using System;

namespace StudentApi.Tests.API_Controllers
{
    [TestClass]
    public class StudentControllerTests
    {       

        [TestMethod]
        public void Post_DebeberiaDevolverCreatedAtRoutResult_CuandoRecibeUnObjetoValido()
        {
            //ARRANGE **            
            
            //Creo un mock que implementará la interfaz IStudentValidator
            var validatorMock = new Mock<IStudentValidator>();

            //Indico al mock su comportamiento esperado (Expectativas). Es básicamente armar un objeto en forma artificial y especificar como debe comportarse.
            //Rocordar que este mock es una DEPENDENCIA del objeto que realmente quiero probar (sut), y desde el punto de vista el sut, asumimos que funcioana bien.

            //1) Instancio el objeto que va a recibir el método POST como parámetro. Me interesa para ESTA prueba, que sea válido:
            Student student = new Student() { Name = "Maria", YearOfBirth = 2001 };

            //2) Defino el comportamiento del mock para esta prueba:
            validatorMock
                .Setup(vm => vm.Validate(student))                                /* 2.1) Cuando le invoquen el método Validate 
                                                                                   *      pasando por parámetro la instancia de student que definimos */ 
                .Returns(new CustomValidationResult(true, new List<string> { })); // 2.3) Deberá devolver un objeto del tipo CustomValidationResult "positivo" (Sin errores

            //3) Creo un mock que implementará la interfaz IStudentBusinessLogic.       
            var studentBLMock = new Mock<IStudentService>();
            studentBLMock.Setup(m => m.AddStudent(student));
        
            //Ahora, instancio el SUT (StudentController en este caso) pasándole por parámetro las dependencias (mocks) creados antes.
            //Para referirme al objeto mock realmente que quierio inyectar como dependencias debo acceder a la propiedad Object como puede verse
            //en la siguiente línea. Con esto, finalizo la parte de "Arrange" para este test y puedo asegurar que estoy probando mi StudentController
            //"en forma unitaria". Es decir, su lógica exclusiva, y no la de sus dependencias.
            StudentController sut = 
                                      //Mock que implementa IStuentBusinessLogic 
                new StudentController(studentBLMock.Object,
                                      //Mock que implementa IStudentValidator
                                      validatorMock.Object);

            //ACT **

            //Ejecuto el o los pasos necesarios para la prueba que quiero llevar a cabo:    
            // 1) Ejecuto el método POST. Es como si lo llamáramos desde otra aplicación, como Postman
            var result = sut.Post(student);
            // 2) "Capturo" el valor devueto (Recordar la función del operador "as" en C#)
            var expectedResult = result as CreatedAtRouteResult; 


            //ASSERT **
           
            //Compruebo el resultado de mi prueba. 
            Assert.IsNotNull(expectedResult);

            //Verifico que los métodos que definí (Setup) para mis mockS, hayan sido realmente ejecutados por el SUT
            validatorMock.VerifyAll();
            studentBLMock.VerifyAll();
        }

        [TestMethod]
        public void Post_DeberiaRetornarBadRequestObjectResult_CuandoRecibeUnObetoInvalido()
        {
            //ARRANGE **

            //Creo un mock que implementará la interfaz IStudentValidator
            Student student = null;
            var validatorMock = new Mock<IStudentValidator>();
            validatorMock.Setup(vm => vm.Validate(student)).Returns(new CustomValidationResult(false,   //Este valor me interesa porque mi sut lo usa.
                                                                    new List<string> {"Objeto Nulo"})); //Este no en realidad, pero igualmente lo defino porque no me cuesta
            
            //Creo un mock que implementará la interfaz IStudentBusinessLogic. 
            var studentBLMock = new Mock<IStudentService>();
            studentBLMock.Setup(m => m.AddStudent(student));

            //Instancio el SUT ("System/Subject Under Test" y le inyecto las dependencias) 
            StudentController sut = new StudentController(studentBLMock.Object, validatorMock.Object);
                  
            //ACT **

            //Ejecuto el o los pasos necesarios para la prueba que quiero llevar a cabo.
            var result = sut.Post(student);
            var expectedResult = result as BadRequestObjectResult;
                     
            //ASSERT ** 

            //En este caso, me basta con verificar que expectedResult no es nulo...
            Assert.IsNotNull(expectedResult);
           
            //Verifico que los métodos que definí (Setup) para mis mockS, hayan sido realmente ejecutados por el SUT
            validatorMock.VerifyAll();
            studentBLMock.VerifyAll();

        }

        [TestMethod]
        public void Post_DeberiaRetornarStatusCode500_CuandoOcurraUnError()
        {
            //ARRANGE **
 
            var validatorMock = new Mock<IStudentValidator>();                 
            validatorMock.Setup(vm => vm.Validate(It.IsNotNull<Student>())) //No me preocupa tanto el comportamiento del mock en este caso.. simplemente exijo que no sea null                
                         .Returns(new CustomValidationResult(true, new List<string> { }));

            //Pero... quiero simular una excepción en la capa de negocios por ejemplo, para verificar que mi controller la capture
            //Básicamente estoy diciendo: No importa el parámetro recibido, quiero que mi lógica de negocios falle.
            var studentBLMock = new Mock<IStudentService>();
            studentBLMock.Setup(sbl => sbl.AddStudent(It.IsAny<Student>())).Throws(new Exception());

            //Instancio el SUT ("System/Subject Under Test" y le inyecto las dependencias) 
            StudentController sut = new StudentController(studentBLMock.Object, validatorMock.Object);


            //ACT **
            var result = sut.Post(new Student());
            var expectedResult = result as ObjectResult;

            
            //ASSERT **
            
            Assert.AreNotEqual(null, expectedResult);
            Assert.AreEqual(500, expectedResult.StatusCode.Value);

            validatorMock.VerifyAll();
            studentBLMock.VerifyAll();
        }
    }
}
