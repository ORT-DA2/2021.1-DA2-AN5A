using Microsoft.VisualStudio.TestTools.UnitTesting;
using Students.BusinessLogic.Validators;
using Students.Domain.Model;
using System;

namespace BusinessLogicLayer.Tests
{
    [TestClass]
    public class StudentValidatorTests
    {
        [TestMethod]
        public void Validate_DeberiaLanzarExcepcion_CuandoRecibeParametroNull()
        {
            //ARRANGE **

            //Instancio el SUT ("System/Subject Under Test") 
            StudentValidator validator = new StudentValidator(); 

            //"Instancio" su dependencia, en este lo que correponde a un par�metro
            Student student = null;
                              

            //ACT - ASSERT **

            Assert.ThrowsException<Exception>(() => validator.Validate(student));
                                    
        }

        [TestMethod]
        public void Validate_DeberiaRetornarFalse_ParaEstudianteConNombreEnNull()
        {
            //ARRANGE

            //Instancio el SUT ("System/Subject Under Test") 
            StudentValidator sut = new StudentValidator();

            //"Instancio" su dependencia, en este lo que correponde a un par�metro
            Student student = new Student()
            {
                Name = null,
                YearOfBirth = 1993
            };

          

            //ACT

            //Ejecuto el o los pasos necesarios para la prueba que quiero llevar a cabo.
            CustomValidationResult result = sut.Validate(student);

            

            //ASSERT

            //Como le pas� una instancia con nombre inv�lido, espero que el resultado sea false para dar la prueba como v�lida.
            Assert.IsFalse(result.IsValid);

            //Adem�s, espero encontrar el mensaje de error correcto en la lista de mensajes de error.
            Assert.IsTrue(result.ErrorMessages != null && result.ErrorMessages.Count == 1); // --> Me aseguro que contiene EXACTAMENTE un mensaje de error
            Assert.AreEqual(result.ErrorMessages[0], "El nombre es un campo requerido"); //--> Me aseguro de obtener el mensaje de error CORRECTO
                        
        }

        [TestMethod]
        public void Validate_DeberiaRetornarFalse_ParaEstudianteConNombreEnBlanco()
        {
            //ARRANGE

            //Instancio el SUT ("System/Subject Under Test") 
            StudentValidator sut = new StudentValidator();

            //"Instancio" su dependencia, en este lo que correponde a un par�metro
            Student student = new Student()
            {
                Name = "",
                YearOfBirth = 2000
            };
                        

            //ACT

            //Ejecuto el o los pasos necesarios para la prueba que quiero llevar a cabo.
            CustomValidationResult result = sut.Validate(student);


            //ASSERT 

            //Como le pas� una instancia con nombre inv�lido, espero que el resultado sea false para dar la prueba como correcta.
            Assert.IsFalse(result.IsValid);

            //Adem�s, espero encontrar el mensaje de error correcto en la lista de mensajes de error.
            Assert.IsTrue(result.ErrorMessages != null && result.ErrorMessages.Count == 1); // --> Me aseguro que contiene EXACTAMENTE un mensaje de error
            Assert.AreEqual(result.ErrorMessages[0], "El nombre es un campo requerido");    // --> Me aseguro de obtener el mensaje de error CORRECTO
                       
        }

        [TestMethod]
        public void Validate_DeberiaRetornarFalse_ParaFechaDeNacimientoNegativa()
        {
            //ARRANGE

            //Instancio el SUT ("System/Subject Under Test") 
            StudentValidator sut = new StudentValidator();

            //"Instancio" su dependencia, en este lo que correponde a un par�metro
            Student student = new Student()
            {
                Name = "Juan Perez",
                YearOfBirth = -1 
            };

           

            //ACT

            //Ejecuto el o los pasos necesarios para la prueba que quiero llevar a cabo.
            CustomValidationResult result = sut.Validate(student);

        

            //ASSERT

            //Como le pas� una instancia con a�o de nacimiento nagativo, espero que el resultado sea false para dar la prueba como v�lida.
            Assert.IsFalse(result.IsValid);

            //Adem�s, espero encontrar el mensaje de error correcto en la lista de mensajes de error.
            Assert.IsTrue(result.ErrorMessages != null && result.ErrorMessages.Count == 1); // --> Me aseguro que contiene EXACTAMENTE un mensaje de error
            Assert.AreEqual(result.ErrorMessages[0], "El a�o de nacimiento es inv�lido"); //--> Me aseguro de obtener el mensaje de error CORRECTO

        }

        [TestMethod]
        public void Validate_DeberiaRetornarFalse_ParaEstudianteMenorDeEdad()
        {
            //ARRANGE

            //Instancio el SUT ("System/Subject Under Test") 
            StudentValidator sut = new StudentValidator();

            //"Instancio" su dependencia, en este lo que correponde a un par�metro
            Student student = new Student()
            {
                Name = "Juan Perez",
                YearOfBirth = DateTime.Today.Year - 17 //Evito hacer "hard coding" del a�o de nacimiento, y me aseguro que mi prueba sigue siendo v�lida con el paso de los a�os
            };


            //ACT

            //Ejecuto el o los pasos necesarios para la prueba que quiero llevar a cabo.
            CustomValidationResult result = sut.Validate(student);


            //ASSERT

            //Como le pas� una instancia con a�o de nacimiento nagativo, espero que el resultado sea false para dar la prueba como v�lida.
            Assert.IsFalse(result.IsValid);

            //Adem�s, espero encontrar el mensaje de error correcto en la lista de mensajes de error.
            Assert.IsTrue(result.ErrorMessages != null && result.ErrorMessages.Count == 1); // --> Me aseguro que contiene EXACTAMENTE un mensaje de error
            Assert.AreEqual(result.ErrorMessages[0], "Debe ser mayor de edad"); //--> Me aseguro de obtener el mensaje de error CORRECTO

        }

        [TestMethod]
        public void Validate_DeberiaRetornarFalse_ParaEstudianteConDatosInvalidos()
        {
            //ARRANGE

            //Instancio el SUT ("System/Subject Under Test") 
            StudentValidator sut = new StudentValidator();

            //"Instancio" su dependencia, en este lo que correponde a un par�metro
            Student student = new Student()
            {
                Name = "", // --> Deber�a incluir otro m�todo de test, pero que asigne null al nombre
                YearOfBirth = DateTime.Today.Year - 17 //Evito hacer "hard coding" del a�o de nacimiento, y me aseguro que mi prueba sigue siendo v�lida con el paso de los a�os
            };

            //ACT

            //Ejecuto el o los pasos necesarios para la prueba que quiero llevar a cabo.
            CustomValidationResult result = sut.Validate(student);


            //ASSERT

            //Como le pas� una instancia con a�o de nacimiento nagativo, espero que el resultado sea false para dar la prueba como v�lida.
            Assert.IsFalse(result.IsValid);

            //Adem�s, espero encontrar LOS mensaje de error CORRECTOS en la lista de mensajes de error.
            Assert.IsTrue(result.ErrorMessages != null && result.ErrorMessages.Count == 2); // --> Me aseguro que contiene EXACTAMENTE DOS mensaje de error

            //Me aseguro de obtener LOS mensajes de error CORRECTOS, pero no me importa mucho el orden
            Assert.IsTrue(result.ErrorMessages.Contains("Debe ser mayor de edad"));
            Assert.IsTrue(result.ErrorMessages.Contains("El nombre es un campo requerido"));

        }

        [TestMethod]
        public void Validate_DeberiaRetornarTrue_EstudiandteConDatosCorrectos()
        {
            //ARRANGE

            //Instancio el SUT ("System/Subject Under Test") 
            StudentValidator sut = new StudentValidator();

            //"Instancio" su dependencia, en este lo que correponde a un par�metro
            Student student = new Student()
            {
                Name = "Pepe", // --> Deber�a incluir otro m�todo de test, pero que asigne null al nombre
                YearOfBirth = 2000 //Evito hacer "hard coding" del a�o de nacimiento, y me aseguro que mi prueba sigue siendo v�lida con el paso de los a�os
            };


            //ACT

            //Ejecuto el o los pasos necesarios para la prueba que quiero llevar a cabo.
            CustomValidationResult result = sut.Validate(student);


            //ASSERT

            Assert.IsTrue(result.IsValid);
        }

    }
}
