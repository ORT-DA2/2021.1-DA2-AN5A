﻿using ReflectionExample.Contracts;


namespace Reflectio.RemoteLogger
{
    public class RemoteLogger : ICustomLogger
    {       
        public string LogDestination
        {
            get
            {
                return "https://mi-servidor/logs-ejecucion";
            }

        }

        public string Log(string message)
        {
            //Acá estaría implementada la lógica para guardar el mensaje recibido en algún endpoint

            return $"{message}  --> Guardado en la url: {LogDestination}";
        }
    }
}
