﻿using ReflectionExample.Main.LogManager;
using System;
using System.Reflection;
using System.Linq;
using System.IO;
using System.Diagnostics;
using ReflectionExample.Contracts;

namespace Reflection
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Los dos métodos mencionados abajo representan posibles maneras de cargar una dll dinámicamente en el contexto de la aplicación.
             * El primero, para trabajar en forma "directa", y el segundo mediante una interfaz (Lo que considero mucho más recomendable).
             * Ambos métodos trabajan con el mismo archivo de configuración, por lo cual si lo modifican, verán reflejado el cambio en los dos casos.
             * Recomiendo que recompilen la solución para volver a generar las dlls, que no estarán disponibles en el zip que les estoy enviando.
             * Prueben ubicar esas dlls en algún otro lugar, prueben, investiguen, inspeccionen las variables :) */

             LoadDirectly();


            // LoadThroughInterface();

            Console.ReadKey();

        }


        private static void LoadDirectly()
        {
            //Desde la configuración, leemos el nombre del assembly que contiene a la clase que necesito instanciar dinámicamente
            string AssemblyFileName = LoggingConfiguration.AssemblyName;

            //Creamos una instancia en memoria de la clase Assembly, indicándole el nombre de la dll
            Assembly loggerAssembly = Assembly.LoadFrom(AssemblyFileName);

            //Obtengo la primer clase -la única de hecho- cuyo nombre termine con "Logger" (Lo puedo hacer porque sé de antemano que hay una)
            //Y me creo una instancia de ella.
            var loggerType = loggerAssembly.GetTypes().Where(t => t.Name.EndsWith("Logger")).FirstOrDefault();
            var loggerIntance = Activator.CreateInstance(loggerType);

            //Finalmente, solo resta invcar al método Log. Primero, obtengo una referencia al método.
            MethodInfo logMethod = loggerIntance.GetType().GetMethod("Log");

            //Ordenamos guardar log de algún mensaje
            string logResult = (string)logMethod.Invoke(loggerIntance, new string[] { "Mensaje de prueba, instanciando directamente (Sin interfaz implementada)." });

            //Y por último imprimimos el resultado.
            Console.WriteLine(logResult);
            Console.WriteLine("Presione cualquier tecla para finalizar");
        }


        private static void LoadThroughInterface()
        {
            //**** "Setup" inicial para empezar a trabajar ****
            //*************************************************

            //Desde la configuración, leemos el nombre del assembly que contiene a la clase que necesito instanciar dinámicamente
            string AssemblyFileName = LoggingConfiguration.AssemblyName;

            //Creamos una instancia en memoria de la clase Assembly, indicándole el nombre de la dll
            Assembly loggerAssembly = Assembly.LoadFrom(AssemblyFileName);

            //Obtenemos una referencia al tipo de datos (Type) de la interfaz mediante la cual trabajaremos con nuestra clase cargada dinámicamente
            Type loggerInterface = typeof(ICustomLogger);

            //Leemos los tipos de datos (clases) en el assembly que implementan a la interfaz ICustomLogger. 
            //Sabemos de antemano que hay uno solo, así que nos quedamos con el primero (FirstOrDefault())
            var type = loggerAssembly.GetTypes().Where(p => loggerInterface.IsAssignableFrom(p)).FirstOrDefault();

            //Instanciamos la clase localizada en la línea anterior, y la asignamos a una variable del tipo ICustomLogger. Es necesario hacer un cast explícito,
            //Ya que el método Activator.CreateInstance() devuelve un objeto del tipo object.
            ICustomLogger loggerInstance = (ICustomLogger)Activator.CreateInstance(type);


            //**** Finalmente, estamos listos para trabajar con nuestro objeto del tipo customLogger ****
            //*******************************************************************************************

            //Ordenamos guardar log de algún mensaje
            string logResult = loggerInstance.Log("Mensaje de prueba, instanciando a través de una interfaz.");

            //Y por último imprimimos el resultado.
            Console.WriteLine(logResult);
            Console.WriteLine("Presione cualquier tecla para finalizar");
        }
    }
}
