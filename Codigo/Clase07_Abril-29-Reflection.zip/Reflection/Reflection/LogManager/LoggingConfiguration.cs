﻿using Microsoft.Extensions.Configuration;


namespace ReflectionExample.Main.LogManager
{
    /// <summary>
    /// Clase utilitaria para facilitar la lectura del archivo de configuración para Logging. 
    /// </summary>    
    public static class LoggingConfiguration
    {
        /* Para poder funcionar, ésta clase requiere de la instalación de los siguiente paquetes:
         *  - Microsoft.Extensions.Configuration
         *  - Microsoft.Extensions.Configuration.FileExtensions
         *  - Microsoft.Extensions.Configuration.Json
         * 
         * Además, el archivo de configuración debe tener establecida la propiedad "Copy in ouput directory" en "Copy if newer"*/
        
        private static IConfigurationSection _loggingConfigSection;


        /// <summary>
        /// Implementación de un "Singleton" para la sección que de la configuración que nos interesa manejar acá (Logging)
        /// </summary>
        private static IConfigurationSection Instance
        {
            get
            {
                if (_loggingConfigSection == null)
                {
                    var configuration = new ConfigurationBuilder()
                        .AddJsonFile("appsettings.json", true, true).Build();
                    _loggingConfigSection = configuration.GetSection("CustomLogging");
                }

                return _loggingConfigSection;
            }
        }

        /// <summary>
        /// Nombre del ensamblado que con la implementación de logging que quiero utilizar.
        /// </summary>
        public static string AssemblyName
        {
            get
            {
                return Instance["AssemblyName"];
            }
        }

    }
}
