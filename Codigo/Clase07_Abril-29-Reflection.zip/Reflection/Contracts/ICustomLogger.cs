﻿using System;

namespace Reflection.Contracts
{
    public interface ICustomLogger
    {
        string LogAddress { get; set; }

        void Log();
    }
}
