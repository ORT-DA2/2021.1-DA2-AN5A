﻿using ReflectionExample.Contracts;

namespace Reflection.DatabaseLogger
{
    public class DatabaseLogger : ICustomLogger
    {
        public string LogAddress { get; set; }

        public void Log()
        {

        }
    }
}
