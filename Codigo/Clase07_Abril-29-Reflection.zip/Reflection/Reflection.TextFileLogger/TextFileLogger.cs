﻿using ReflectionExample.Contracts;
using System;

namespace Reflection.TextFileLogger
{
    public class TextFileLogger : ICustomLogger
    {
        public string LogDestination
        {
            get
            {
                return "MiArchivoDeLog.txt";
            }
        }

        public string Log(string message)
        {
            //Acá estaría implementada la lógica para guardar el mensaje recibido en un archivo

            return $"{message}  --> Guardado en el archivo: {LogDestination}";
        }
    }
}
