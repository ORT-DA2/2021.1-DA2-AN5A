﻿using System;

namespace ReflectionExample.Contracts
{
    public interface ICustomLogger
    {
        string LogDestination { get; }

        string Log(string message);        
    }
}
